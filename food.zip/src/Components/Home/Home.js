import React from "react";
import "./Home.css";

export default function Home() {
  return (
    <div>
      <img
        className="Home-image"
        src="https://b.zmtcdn.com/data/o2_assets/b90ed7f7c7f06ce7a5b94b967d4ce3eb1621255947.png"
        alt=""
      />
    </div>
  );
}
