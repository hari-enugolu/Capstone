export default [
  {
    title: "The best you can do for the future generation, save food.",
  },

  {
    title: "Think about the ones who cannot afford food.",
  },

  {
    title: "  Everything is limited, please do not waste food.",
  },

  {
    title: "The best you can do for the future generation, save food.",
  },
];
